const dns = require("dns");

dns.setDefaultResultOrder("ipv4first");


const express = require("express");
const dotenv = require("dotenv");
const path = require("path");
const cors = require("cors");


// =====================================================
// LOAD ENVIRONMENT VARIABLES
// =====================================================

dotenv.config({
    path: path.join(__dirname, ".env")
});


console.log(
    "CLIENT_URL:",
    process.env.CLIENT_URL
);


// =====================================================
// CONNECT DATABASE
// =====================================================

const connectDB = require("./config/db");

connectDB();


// =====================================================
// EXPRESS APP
// =====================================================

const app = express();


// =====================================================
// MIDDLEWARE
// =====================================================

app.use(cors());

app.use(express.json());


// =====================================================
// TEST ROUTE
// =====================================================

app.get("/", (req, res) => {

    res.send(
        "Vignesh Tours MERN Backend Running..."
    );

});


// =====================================================
// AUTHENTICATION ROUTES
// =====================================================

const authRoutes = require("./routes/authRoutes");

app.use(
    "/api/auth",
    authRoutes
);


// =====================================================
// PACKAGE ROUTES
// =====================================================

const packageRoutes = require("./routes/packageRoutes");

app.use(
    "/api/packages",
    packageRoutes
);


// =====================================================
// BOOKING ROUTES
// =====================================================

const bookingRoutes = require("./routes/bookingRoutes");

app.use(
    "/api/bookings",
    bookingRoutes
);


// =====================================================
// PAYMENT ROUTES - RAZORPAY
// =====================================================

const paymentRoutes = require("./routes/paymentRoutes");

app.use(
    "/api/payments",
    paymentRoutes
);


// =====================================================
// PORT
// =====================================================

const PORT = process.env.PORT || 5000;


app.listen(PORT, () => {

    console.log(
        `Server running on port ${PORT}`
    );

});