const Razorpay = require("razorpay");
const crypto = require("crypto");
const Booking = require("../models/Booking");
const Package = require("../models/Package");


// =====================================================
// Razorpay Instance
// =====================================================

const razorpay = new Razorpay({

    key_id: process.env.RAZORPAY_KEY_ID,

    key_secret: process.env.RAZORPAY_KEY_SECRET

});


// =====================================================
// CREATE RAZORPAY ORDER
// =====================================================

exports.createOrder = async (req, res) => {

    try {

        const {
            packageId,
            travellers
        } = req.body;


        // Validate input

        if (!packageId || !travellers) {

            return res.status(400).json({

                success: false,

                message:
                    "Package and traveller details are required."

            });

        }


        // Find package

        const packageData = await Package.findById(
            packageId
        );


        if (!packageData) {

            return res.status(404).json({

                success: false,

                message: "Package not found."

            });

        }


        // Price per person

        const pricePerPerson =
            packageData.price ||
            packageData.price_per_person ||
            0;


        // Calculate total

        const totalAmount =
            pricePerPerson * Number(travellers);


        if (totalAmount <= 0) {

            return res.status(400).json({

                success: false,

                message: "Invalid booking amount."

            });

        }


        // Razorpay amount is in paise

        const amountInPaise =
            Math.round(totalAmount * 100);


        // Create Razorpay order

        const options = {

            amount: amountInPaise,

            currency: "INR",

            receipt:
                `receipt_${Date.now()}`,

            notes: {

                packageId:
                    packageId.toString(),

                travellers:
                    Number(travellers)

            }

        };


        const order =
            await razorpay.orders.create(options);


        res.status(200).json({

            success: true,

            order: {

                id: order.id,

                amount: order.amount,

                currency: order.currency

            },

            key: process.env.RAZORPAY_KEY_ID,

            package: {

                id: packageData._id,

                title: packageData.title,

                pricePerPerson

            },

            totalAmount

        });


    } catch (error) {

        console.error(
            "Create Razorpay Order Error:",
            error
        );


        res.status(500).json({

            success: false,

            message:
                "Unable to create Razorpay order."

        });

    }

};



// =====================================================
// VERIFY RAZORPAY PAYMENT
// =====================================================

exports.verifyPayment = async (req, res) => {

    try {

        const {

            razorpay_order_id,

            razorpay_payment_id,

            razorpay_signature,

            bookingData

        } = req.body;


        // Validate Razorpay response

        if (

            !razorpay_order_id ||

            !razorpay_payment_id ||

            !razorpay_signature

        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Payment verification details are missing."

            });

        }


        // Create signature

        const generatedSignature =
            crypto
                .createHmac(
                    "sha256",
                    process.env.RAZORPAY_KEY_SECRET
                )
                .update(
                    `${razorpay_order_id}|${razorpay_payment_id}`
                )
                .digest("hex");


        // Verify signature

        if (
            generatedSignature !==
            razorpay_signature
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Payment verification failed."

            });

        }


        // Payment is verified
        // Now create the booking

        if (!bookingData) {

            return res.status(400).json({

                success: false,

                message:
                    "Booking details are missing."

            });

        }


        const {

            packageId,
            fullName,
            email,
            phone,
            travellers,
            travelDate,
            specialRequest

        } = bookingData;


        // Find package again

        const packageData =
            await Package.findById(packageId);


        if (!packageData) {

            return res.status(404).json({

                success: false,

                message: "Package not found."

            });

        }


        // Calculate amount on backend

        const pricePerPerson =
            packageData.price ||
            packageData.price_per_person ||
            0;


        const totalAmount =
            pricePerPerson *
            Number(travellers);


        // Create booking

        const booking =
            await Booking.create({

                packageId,

                packageName:
                    packageData.title,

                userId:
                    req.user?._id || null,

                fullName,

                email,

                phone,

                travellers,

                travelDate,

                specialRequest,

                pricePerPerson,

                totalAmount,

                bookingStatus:
                    "Confirmed",

                paymentStatus:
                    "Paid",

                razorpayOrderId:
                    razorpay_order_id,

                razorpayPaymentId:
                    razorpay_payment_id,

                razorpaySignature:
                    razorpay_signature

            });


        res.status(200).json({

            success: true,

            message:
                "Payment verified and booking confirmed.",

            booking

        });


    } catch (error) {

        console.error(
            "Payment Verification Error:",
            error
        );


        res.status(500).json({

            success: false,

            message:
                "Unable to verify payment."

        });

    }

};