const Package = require("../models/Package");

const normalizePackage = (pkg) => ({
  _id: pkg._id,

  title: pkg.title || "Untitled Package",

  description:
    pkg.description ||
    "Experience an unforgettable journey with Vignesh Tours.",

  destination: pkg.destination || "",

  price: Number(pkg.price ?? pkg.price_per_person ?? 0),

  price_per_person: Number(
    pkg.price_per_person ?? pkg.price ?? 0
  ),

  duration:
    pkg.duration ||
    (pkg.duration_days
      ? `${pkg.duration_days} Days`
      : "Custom"),

  duration_days: pkg.duration_days || 0,

  image:
    pkg.image ||
    pkg.images?.[0] ||
    pkg.gallery?.[0] ||
    "",

  images: Array.isArray(pkg.images)
    ? pkg.images
    : [],

  gallery: Array.isArray(pkg.gallery)
    ? pkg.gallery
    : [],

  category: pkg.category || "Domestic",

  is_active: pkg.is_active !== false,

  highlights: Array.isArray(pkg.highlights)
    ? pkg.highlights
    : [],

  inclusions: Array.isArray(pkg.inclusions)
    ? pkg.inclusions
    : [],

  exclusions: Array.isArray(pkg.exclusions)
    ? pkg.exclusions
    : [],

  experiences: Array.isArray(pkg.experiences)
    ? pkg.experiences
    : [],

  itinerary: Array.isArray(pkg.itinerary)
    ? pkg.itinerary
    : [],

  reviews: Array.isArray(pkg.reviews)
    ? pkg.reviews
    : [],

  hotel: pkg.hotel || "",

  transport: pkg.transport || "",

  tour_type: pkg.tour_type || "",

  rating: pkg.rating || 0,

  max_seats: pkg.max_seats || 0,

  available_seats: pkg.available_seats || 0,

  best_time: pkg.best_time || "",

  createdAt: pkg.createdAt,

  updatedAt: pkg.updatedAt,
});


// ==========================================
// Get All Packages
// ==========================================

exports.getPackages = async (req, res) => {
  try {
    const packages = await Package.find({ is_active: { $ne: false } }).sort({
      createdAt: -1,
    });

    res.status(200).json(
      packages.map(normalizePackage)
    );
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch packages.",
      error: error.message,
    });
  }
};


// ==========================================
// Get Package By ID
// ==========================================

exports.getPackageById = async (req, res) => {
  try {
    const packageData = await Package.findById(
      req.params.id
    );

    if (!packageData) {
      return res.status(404).json({
        message: "Package not found.",
      });
    }

    res.status(200).json(
      normalizePackage(packageData)
    );
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch package.",
      error: error.message,
    });
  }
};


// ==========================================
// Create Package
// ==========================================

exports.createPackage = async (req, res) => {
  try {
    if (!req.body.title?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Package title is required.",
      });
    }

    if (Number(req.body.price) < 0) {
      return res.status(400).json({
        success: false,
        message: "Package price cannot be negative.",
      });
    }

    const packageData = await Package.create(req.body);

    res.status(201).json({
      success: true,
      message: "Package created successfully.",
      package: normalizePackage(packageData),
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Unable to create package.",
      error: error.message,
    });
  }
};


// ==========================================
// Update Package
// ==========================================

exports.updatePackage = async (req, res) => {
  try {
    const packageData =
      await Package.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
          new: true,
          runValidators: true,
        }
      );

    if (!packageData) {
      return res.status(404).json({
        message: "Package not found.",
      });
    }

    res.status(200).json({
      success: true,
      message: "Package updated successfully.",
      package: normalizePackage(packageData),
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Unable to update package.",
      error: error.message,
    });
  }
};


// ==========================================
// Delete Package
// ==========================================

exports.deletePackage = async (req, res) => {
  try {
    const packageData =
      await Package.findByIdAndDelete(
        req.params.id
      );

    if (!packageData) {
      return res.status(404).json({
        message: "Package not found.",
      });
    }

    res.status(200).json({
      success: true,
      message: "Package deleted successfully.",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Unable to delete package.",
      error: error.message,
    });
  }
};