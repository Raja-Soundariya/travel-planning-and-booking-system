const Booking = require("../models/Booking");
const Package = require("../models/Package");

// ===============================
// Create Booking
// ===============================
exports.createBooking = async (req, res) => {
  try {
    const {
      packageId,
      fullName,
      email,
      phone,
      travellers,
      travelDate,
      specialRequest,
    } = req.body;

    // Check package exists
    const packageData = await Package.findById(packageId);

    if (!packageData) {
      return res.status(404).json({
        success: false,
        message: "Package not found",
      });
    }

    const pricePerPerson =
      packageData.price || packageData.price_per_person || 0;

    const totalAmount = pricePerPerson * Number(travellers);

    const booking = await Booking.create({
      packageId,
      packageName: packageData.title,
      userId: req.user?._id || null, // Optional for now

      fullName,
      email,
      phone,

      travellers,
      travelDate,
      specialRequest,

      pricePerPerson,
      totalAmount,

      bookingStatus: "Pending",
      paymentStatus: "Pending",
    });

    res.status(201).json({
      success: true,
      message: "Booking created successfully",
      booking,
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Server Error",
    });
  }
};

// ===============================
// Get All Bookings
// ===============================
exports.getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("packageId")
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      bookings,
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Server Error",
    });
  }
};

// ===============================
// Get Booking By ID
// ===============================
exports.getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate(
      "packageId"
    );

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    res.json({
      success: true,
      booking,
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Server Error",
    });
  }
};

// ===============================
// Update Booking Status
// ===============================
exports.updateBookingStatus = async (req, res) => {
  try {
    const allowedBookingStatuses = ["Pending", "Confirmed", "Cancelled"];
    const allowedPaymentStatuses = ["Pending", "Paid", "Failed"];
    const { bookingStatus, paymentStatus } = req.body;

    if (bookingStatus && !allowedBookingStatuses.includes(bookingStatus)) {
      return res.status(400).json({ message: "Invalid booking status" });
    }

    if (paymentStatus && !allowedPaymentStatuses.includes(paymentStatus)) {
      return res.status(400).json({ message: "Invalid payment status" });
    }

    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    booking.bookingStatus = bookingStatus || booking.bookingStatus;

    booking.paymentStatus = paymentStatus || booking.paymentStatus;

    await booking.save();

    res.json({
      success: true,
      message: "Booking updated successfully",
      booking,
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Server Error",
    });
  }
};

// ===============================
// Delete Booking
// ===============================
exports.deleteBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    await booking.deleteOne();

    res.json({
      success: true,
      message: "Booking deleted successfully",
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Server Error",
    });
  }
};