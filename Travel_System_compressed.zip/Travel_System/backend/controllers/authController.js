const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const nodemailer = require("nodemailer");


// =====================================================
// REGISTER USER
// =====================================================

exports.register = async (req, res) => {
    try {

        const {
            name,
            email,
            phone,
            password
        } = req.body;


        // Check existing user
        const existingUser = await User.findOne({
            email
        });


        if (existingUser) {

            return res.status(400).json({
                message: "User already exists"
            });

        }


        // Hash password
        const hashedPassword =
            await bcrypt.hash(password, 10);


        // Create user
        const user = await User.create({

            name,
            email,
            phone,
            password: hashedPassword

        });


        res.status(201).json({

            message:
                "User registered successfully",

            user

        });


    } catch (error) {

        console.error(
            "Register Error:",
            error
        );


        res.status(500).json({

            message:
                error.message

        });

    }
};


// =====================================================
// LOGIN USER
// =====================================================

exports.login = async (req, res) => {

    try {

        const {
            email,
            password
        } = req.body;


        // Find user
        const user = await User.findOne({
            email
        });


        if (!user) {

            return res.status(404).json({

                message:
                    "User not found"

            });

        }


        // Compare password
        const isMatch =
            await bcrypt.compare(
                password,
                user.password
            );


        if (!isMatch) {

            return res.status(400).json({

                message:
                    "Invalid password"

            });

        }


        // Create JWT
        const token = jwt.sign(

            {
                id: user._id,
                role: user.role
            },

            process.env.JWT_SECRET,

            {
                expiresIn: "1d"
            }

        );


        res.json({

            message:
                "Login successful",

            token,

            user: {

                id: user._id,

                name: user.name,

                email: user.email,

                role: user.role

            }

        });


    } catch (error) {

        console.error(
            "Login Error:",
            error
        );


        res.status(500).json({

            message:
                error.message

        });

    }
};


// =====================================================
// FORGOT PASSWORD
// =====================================================

exports.forgotPassword = async (req, res) => {

    try {

        const { email } = req.body;


        // Find user
        const user = await User.findOne({
            email
        });


        // Don't reveal whether account exists
        if (!user) {

            return res.status(200).json({

                message:
                    "If an account exists with this email, a password reset link has been sent."

            });

        }


        // =================================================
        // GENERATE RESET TOKEN
        // =================================================

        const resetToken =
            crypto.randomBytes(32).toString("hex");


        // Hash token before storing in database
        const hashedToken =
            crypto
                .createHash("sha256")
                .update(resetToken)
                .digest("hex");


        // Save token
        user.resetPasswordToken =
            hashedToken;


        // Token expires after 15 minutes
        user.resetPasswordExpire =
            Date.now() +
            15 * 60 * 1000;


        await user.save();


        // =================================================
        // CREATE RESET URL
        // =================================================

        // Use CLIENT_URL from .env.
        // Fallback prevents "http://undefined/..."
        const clientURL =
            process.env.CLIENT_URL ||
            "http://localhost:5173";


        const resetURL =
            `${clientURL}/reset-password/${resetToken}`;


        console.log(
            "CLIENT URL:",
            clientURL
        );


        console.log(
            "RESET URL:",
            resetURL
        );


        // =================================================
        // GMAIL TRANSPORTER
        // =================================================

        const transporter =
            nodemailer.createTransport({

                service: "gmail",

                auth: {

                    user:
                        process.env.MAIL_USER,

                    pass:
                        process.env.MAIL_PASS

                }

            });


        // =================================================
        // SEND EMAIL
        // =================================================

        await transporter.sendMail({

            from:
                `"Vignesh Tours" <${process.env.MAIL_USER}>`,

            to:
                user.email,

            subject:
                "Vignesh Tours - Password Reset",

            html: `

                <div style="
                    font-family: Arial, sans-serif;
                    max-width: 600px;
                    margin: auto;
                    padding: 30px;
                    border: 1px solid #ddd;
                    border-radius: 10px;
                    background: #ffffff;
                ">

                    <h2 style="
                        text-align: center;
                        color: #0b2347;
                    ">
                        Vignesh Tours
                    </h2>


                    <h3>
                        Password Reset Request
                    </h3>


                    <p>
                        Hello ${user.name},
                    </p>


                    <p>
                        We received a request to reset your password.
                    </p>


                    <p>
                        Click the button below to create a new password.
                    </p>


                    <div style="
                        text-align: center;
                        margin: 30px 0;
                    ">

                        <a
                            href="${resetURL}"
                            style="
                                background: #007bff;
                                color: white;
                                padding: 12px 25px;
                                text-decoration: none;
                                border-radius: 5px;
                                display: inline-block;
                                font-size: 16px;
                            "
                        >
                            Reset Password
                        </a>

                    </div>


                    <p>
                        This link will expire in
                        <strong>15 minutes</strong>.
                    </p>


                    <p>
                        If you did not request a password reset,
                        you can safely ignore this email.
                    </p>


                    <hr>


                    <p style="
                        font-size: 12px;
                        color: #777;
                    ">
                        Vignesh Tours
                    </p>

                </div>

            `

        });


        // =================================================
        // RESPONSE
        // =================================================

        res.status(200).json({

            message:
                "If an account exists with this email, a password reset link has been sent."

        });


    } catch (error) {

        console.error(
            "Forgot Password Error:",
            error
        );


        res.status(500).json({

            message:
                "Unable to send password reset email"

        });

    }

};


// =====================================================
// RESET PASSWORD
// =====================================================

exports.resetPassword = async (req, res) => {

    try {

        const { token } =
            req.params;


        const { password } =
            req.body;


        // =================================================
        // VALIDATE PASSWORD
        // =================================================

        if (
            !password ||
            password.length < 6
        ) {

            return res.status(400).json({

                message:
                    "Password must be at least 6 characters"

            });

        }


        // =================================================
        // HASH TOKEN
        // =================================================

        const hashedToken =
            crypto
                .createHash("sha256")
                .update(token)
                .digest("hex");


        // =================================================
        // FIND USER
        // =================================================

        const user =
            await User.findOne({

                resetPasswordToken:
                    hashedToken,

                resetPasswordExpire: {
                    $gt: Date.now()
                }

            });


        if (!user) {

            return res.status(400).json({

                message:
                    "Password reset link is invalid or has expired"

            });

        }


        // =================================================
        // HASH NEW PASSWORD
        // =================================================

        const hashedPassword =
            await bcrypt.hash(
                password,
                10
            );


        // =================================================
        // UPDATE PASSWORD
        // =================================================

        user.password =
            hashedPassword;


        // =================================================
        // REMOVE RESET TOKEN
        // =================================================

        user.resetPasswordToken =
            undefined;


        user.resetPasswordExpire =
            undefined;


        await user.save();


        // =================================================
        // SUCCESS RESPONSE
        // =================================================

        res.status(200).json({

            message:
                "Password reset successful. You can now login."

        });


    } catch (error) {

        console.error(
            "Reset Password Error:",
            error
        );


        res.status(500).json({

            message:
                "Unable to reset password"

        });

    }

};