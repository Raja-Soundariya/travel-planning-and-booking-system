const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

const connectDB = require("../config/db");
const Package = require("../models/Package");

const packagesPath = path.join(__dirname, "..", "..", "vignesh_tours.packages.json");

const parseObjectId = (value) => {
  if (!value) return undefined;
  if (typeof value === "string") return mongoose.Types.ObjectId.isValid(value) ? new mongoose.Types.ObjectId(value) : undefined;
  if (value.$oid) return new mongoose.Types.ObjectId(value.$oid);
  return undefined;
};

const importPackages = async () => {
  try {
    const raw = fs.readFileSync(packagesPath, "utf8");
    const records = JSON.parse(raw);

    await connectDB();

    for (const entry of records) {
      const normalized = {
        _id: parseObjectId(entry._id?.$oid || entry._id),
        title: entry.title,
        destination: entry.destination || "",
        description: entry.description || "",
        price: entry.price_per_person || entry.price || 0,
        price_per_person: entry.price_per_person || entry.price || 0,
        duration: entry.duration || (entry.duration_days ? `${entry.duration_days} Days` : ""),
        duration_days: entry.duration_days || 0,
        image: Array.isArray(entry.images) && entry.images.length > 0 ? entry.images[0] : "",
        images: Array.isArray(entry.images) ? entry.images : [],
        gallery: Array.isArray(entry.gallery) ? entry.gallery : [],
        category: entry.category || "domestic",
        is_active: entry.is_active !== false,
        highlights: Array.isArray(entry.highlights) ? entry.highlights : [],
        hotel: entry.hotel || "",
        rating: entry.rating || 0,
        transport: entry.transport || "",
        tour_type: entry.tour_type || "",
        itinerary: Array.isArray(entry.itinerary) ? entry.itinerary : [],
        reviews: Array.isArray(entry.reviews) ? entry.reviews : [],
        inclusions: Array.isArray(entry.inclusions) ? entry.inclusions : [],
        exclusions: Array.isArray(entry.exclusions) ? entry.exclusions : [],
        max_seats: entry.max_seats || 0,
        available_seats: entry.available_seats || 0,
        best_time: entry.best_time || "",
        createdAt: entry.created_at ? new Date(entry.created_at.$date || entry.created_at) : undefined,
        updatedAt: new Date()
      };

      const query = entry._id?.$oid ? { _id: normalized._id } : { title: entry.title };

      await Package.updateOne(query, { $set: normalized }, { upsert: true });
      console.log(`Imported: ${entry.title}`);
    }

    console.log("✅ Package import completed");
    process.exit(0);
  } catch (error) {
    console.error("❌ Package import failed");
    console.error(error.message);
    process.exit(1);
  }
};

importPackages();
