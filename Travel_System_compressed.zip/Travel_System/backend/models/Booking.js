const mongoose = require("mongoose");


const bookingSchema = new mongoose.Schema(

    {

        // ===============================
        // Package Details
        // ===============================

        packageId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Package",
            required: true,
        },


        packageName: {
            type: String,
            required: true,
        },


        // ===============================
        // User Details
        // ===============================

        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },


        fullName: {
            type: String,
            required: true,
            trim: true,
        },


        email: {
            type: String,
            required: true,
            trim: true,
            lowercase: true,
        },


        phone: {
            type: String,
            required: true,
            trim: true,
        },


        // ===============================
        // Travel Details
        // ===============================

        travellers: {
            type: Number,
            required: true,
            default: 1,
            min: 1,
        },


        travelDate: {
            type: Date,
            required: true,
        },


        specialRequest: {
            type: String,
            default: "",
            trim: true,
        },


        // ===============================
        // Price Details
        // ===============================

        pricePerPerson: {
            type: Number,
            required: true,
        },


        totalAmount: {
            type: Number,
            required: true,
        },


        // ===============================
        // Booking Status
        // ===============================

        bookingStatus: {
            type: String,
            enum: [
                "Pending",
                "Confirmed",
                "Cancelled"
            ],
            default: "Pending",
        },


        // ===============================
        // Payment Status
        // ===============================

        paymentStatus: {
            type: String,
            enum: [
                "Pending",
                "Paid",
                "Failed"
            ],
            default: "Pending",
        },


        // ===============================
        // Razorpay Details
        // ===============================

        razorpayOrderId: {
            type: String,
            default: null,
        },


        razorpayPaymentId: {
            type: String,
            default: null,
        },


        razorpaySignature: {
            type: String,
            default: null,
        },

    },

    {
        timestamps: true,
    }

);


module.exports = mongoose.model(
    "Booking",
    bookingSchema
);