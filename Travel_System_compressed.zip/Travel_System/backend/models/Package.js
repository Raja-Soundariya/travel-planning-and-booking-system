const mongoose = require("mongoose");

const packageSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    destination: {
        type: String,
        default: ""
    },
    description: {
        type: String,
        default: ""
    },
    price: {
        type: Number,
        default: 0
    },
    price_per_person: {
        type: Number,
        default: 0
    },
    duration: {
        type: String,
        default: ""
    },
    duration_days: {
        type: Number,
        default: 0
    },
    image: {
        type: String,
        default: ""
    },
    images: {
        type: [String],
        default: []
    },
    gallery: {
        type: [String],
        default: []
    },
    category: {
        type: String,
        default: "domestic"
    },
    is_active: {
        type: Boolean,
        default: true
    },
    highlights: {
        type: [String],
        default: []
    },
    hotel: {
        type: String,
        default: ""
    },
    rating: {
        type: Number,
        default: 0
    },
    transport: {
        type: String,
        default: ""
    },
    tour_type: {
        type: String,
        default: ""
    },
    itinerary: {
        type: Array,
        default: []
    },
    reviews: {
        type: Array,
        default: []
    },
    inclusions: {
        type: [String],
        default: []
    },
    exclusions: {
        type: [String],
        default: []
    },
    max_seats: {
        type: Number,
        default: 0
    },
    available_seats: {
        type: Number,
        default: 0
    },
    best_time: {
        type: String,
        default: ""
    }
}, {
    timestamps: true,
    strict: false
});

module.exports = mongoose.model("Package", packageSchema);