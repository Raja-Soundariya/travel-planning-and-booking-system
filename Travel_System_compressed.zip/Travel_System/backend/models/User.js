const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true
        },

        email: {
            type: String,
            required: true,
            unique: true
        },

        phone: {
            type: String,
            required: true
        },

        password: {
            type: String,
            required: true
        },

        // User or Admin
        role: {
            type: String,
            enum: ["user", "admin"],
            default: "user"
        },

        // Password reset fields
        resetPasswordToken: {
            type: String
        },

        resetPasswordExpire: {
            type: Date
        }
    },
    {
        timestamps: true
    }
);

module.exports = mongoose.model("User", userSchema);