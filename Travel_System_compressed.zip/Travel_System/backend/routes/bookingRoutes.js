const express = require("express");

const router = express.Router();

const {
  createBooking,
  getBookings,
  getBookingById,
  updateBookingStatus,
  deleteBooking,
} = require("../controllers/bookingController");

const { protect, adminOnly } = require("../middleware/authMiddleware");

// ==============================
// Create Booking
// POST /api/bookings
// ==============================
router.post("/", createBooking);

// ==============================
// Get All Bookings
// GET /api/bookings
// ==============================
router.get("/", protect, adminOnly, getBookings);

// ==============================
// Get Booking By ID
// GET /api/bookings/:id
// ==============================
router.get("/:id", getBookingById);

// ==============================
// Update Booking
// PUT /api/bookings/:id
// ==============================
router.put("/:id", protect, adminOnly, updateBookingStatus);

// ==============================
// Delete Booking
// DELETE /api/bookings/:id
// ==============================
router.delete("/:id", protect, adminOnly, deleteBooking);

module.exports = router;