const express = require("express");

const router = express.Router();

const {
    createOrder,
    verifyPayment
} = require("../controllers/paymentController");


// =====================================================
// CREATE RAZORPAY ORDER
// =====================================================

router.post(
    "/create-order",
    createOrder
);


// =====================================================
// VERIFY RAZORPAY PAYMENT
// =====================================================

router.post(
    "/verify",
    verifyPayment
);


module.exports = router;