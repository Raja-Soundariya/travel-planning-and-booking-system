const express = require("express");

const router = express.Router();

const {
    getPackages,
    getPackageById,
    createPackage,
    updatePackage,
    deletePackage
}=require("../controllers/packageController");

const { protect, adminOnly } = require("../middleware/authMiddleware");


// GET all packages
router.get("/", getPackages);

// GET package by id
router.get("/:id", getPackageById);

// CREATE package
router.post("/", protect, adminOnly, createPackage);

// UPDATE package
router.put("/:id", protect, adminOnly, updatePackage);

// DELETE package
router.delete("/:id", protect, adminOnly, deletePackage);


module.exports = router;