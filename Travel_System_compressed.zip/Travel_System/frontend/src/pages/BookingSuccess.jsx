import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import API from "../services/api";
import "./BookingSuccess.css";

function BookingSuccess() {
  const { id } = useParams();

  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // =====================================================
  // FETCH BOOKING DETAILS
  // =====================================================

  useEffect(() => {
    const fetchBooking = async () => {
      try {
        const res = await API.get(`/bookings/${id}`);

        setBooking(res.data.booking || res.data);
      } catch (err) {
        console.error("Error fetching booking:", err);

        setError("Unable to load booking details.");
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchBooking();
    }
  }, [id]);

  // =====================================================
  // LOADING
  // =====================================================

  if (loading) {
    return (
      <div className="success-page">
        <div className="success-card">
          <h2>Loading Booking Details...</h2>
        </div>
      </div>
    );
  }

  // =====================================================
  // ERROR
  // =====================================================

  if (error || !booking) {
    return (
      <div className="success-page">
        <div className="success-card">
          <div className="success-icon">✓</div>

          <h1>🎉 Booking Confirmed!</h1>

          <p className="success-message">
            Your payment was successful and your tour
            booking has been confirmed.
          </p>

          <div className="booking-id-box">
            <p>Booking ID</p>

            <strong>{id}</strong>

            <small>
              Please keep this ID for future reference.
            </small>
          </div>

          <p>
            Booking details could not be loaded.
          </p>

          <div className="success-actions">
            <Link to="/packages" className="book-btn">
              Explore More Packages
            </Link>

            <Link to="/" className="home-btn">
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // =====================================================
  // BOOKING DATA
  // =====================================================

  const packageData = booking.packageId || booking.package;

  const packageName =
    packageData?.title ||
    booking.packageName ||
    "Tour Package";

  const destination =
    packageData?.destination ||
    booking.destination ||
    "Tour Destination";

  const price =
    packageData?.price ||
    packageData?.price_per_person ||
    booking.price ||
    0;

  const travellers =
    booking.travellers ||
    booking.numberOfTravellers ||
    1;

  const totalAmount =
    booking.totalAmount ||
    booking.totalPrice ||
    price * travellers;

  // =====================================================
  // UI
  // =====================================================

  return (
    <div className="success-page">

      <div className="success-card">

        {/* SUCCESS ICON */}

        <div className="success-icon">
          ✓
        </div>


        {/* TITLE */}

        <h1>
          🎉 Booking Confirmed!
        </h1>


        <p className="success-message">
          Your payment was successful and your
          tour booking has been confirmed.
        </p>


        {/* PAYMENT STATUS */}

        <div className="payment-status">

          <span>✓</span>

          <strong>
            Payment Successful
          </strong>

        </div>


        {/* BOOKING ID */}

        <div className="booking-id-box">

          <p>
            Booking ID
          </p>

          <strong>
            {booking._id || id}
          </strong>

          <small>
            Please keep this ID for future reference.
          </small>

        </div>


        {/* CUSTOMER DETAILS */}

        <div className="booking-details">

          <h2>
            Traveller Details
          </h2>

          <div className="detail-row">

            <span>Name</span>

            <strong>
              {booking.fullName || "N/A"}
            </strong>

          </div>


          <div className="detail-row">

            <span>Email</span>

            <strong>
              {booking.email || "N/A"}
            </strong>

          </div>


          <div className="detail-row">

            <span>Phone</span>

            <strong>
              {booking.phone || "N/A"}
            </strong>

          </div>


          <div className="detail-row">

            <span>Travellers</span>

            <strong>
              {travellers}
            </strong>

          </div>


          <div className="detail-row">

            <span>Travel Date</span>

            <strong>
              {booking.travelDate
                ? new Date(
                    booking.travelDate
                  ).toLocaleDateString("en-IN")
                : "N/A"}
            </strong>

          </div>

        </div>


        {/* PACKAGE DETAILS */}

        <div className="booking-details">

          <h2>
            Package Details
          </h2>

          <div className="detail-row">

            <span>Package</span>

            <strong>
              {packageName}
            </strong>

          </div>


          <div className="detail-row">

            <span>Destination</span>

            <strong>
              {destination}
            </strong>

          </div>


          <div className="detail-row">

            <span>Price / Person</span>

            <strong>
              ₹{price.toLocaleString("en-IN")}
            </strong>

          </div>


          <div className="detail-row total-row">

            <span>Total Amount</span>

            <strong>
              ₹{totalAmount.toLocaleString("en-IN")}
            </strong>

          </div>

        </div>


        {/* PAYMENT DETAILS */}

        <div className="booking-details">

          <h2>
            Payment Details
          </h2>

          <div className="detail-row">

            <span>Payment Status</span>

            <strong className="paid">
              Successful
            </strong>

          </div>


          <div className="detail-row">

            <span>Payment ID</span>

            <strong>
              {booking.razorpayPaymentId ||
                booking.paymentId ||
                "N/A"}
            </strong>

          </div>


          <div className="detail-row">

            <span>Order ID</span>

            <strong>
              {booking.razorpayOrderId ||
                booking.orderId ||
                "N/A"}
            </strong>

          </div>

        </div>


        {/* SPECIAL REQUEST */}

        {booking.specialRequest && (
          <div className="booking-details">

            <h2>
              Special Request
            </h2>

            <p>
              {booking.specialRequest}
            </p>

          </div>
        )}


        {/* ACTION BUTTONS */}

        <div className="success-actions">

          <Link
            to="/packages"
            className="book-btn"
          >
            Explore More Packages
          </Link>


          <Link
            to="/"
            className="home-btn"
          >
            Back to Home
          </Link>

        </div>

      </div>

    </div>
  );
}

export default BookingSuccess;