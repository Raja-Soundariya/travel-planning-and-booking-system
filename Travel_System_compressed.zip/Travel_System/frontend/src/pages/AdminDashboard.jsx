import AdminNavbar from "../components/AdminNavbar";
import { Link } from "react-router-dom";
import "./AdminDashboard.css";


function AdminDashboard() {


  return (

    <>

      <AdminNavbar />


      <main className="admin-dashboard">
        <header className="admin-dashboard-header">
          <span className="section-label">VIGNESH TOURS ADMIN</span>
          <h1>Admin Dashboard</h1>
          <p>Manage packages, bookings, offers, and your customer travel experience.</p>
        </header>




        <div className="admin-cards">


          <div className="admin-card">
            <div className="admin-card-icon" aria-hidden="true">✈</div>
            <h3>
              Manage Packages
            </h3>

            <p>
              Add, edit and delete tour packages.
            </p>


            <Link to="/admin/add-package">
              Add Package
            </Link>


          </div>





          <div className="admin-card">
            <div className="admin-card-icon" aria-hidden="true">🎁</div>
            <h3>
              Offers Management
            </h3>

            <p>
              Create and manage travel offers.
            </p>


            <Link to="/admin/offers">
              Manage Offers
            </Link>


          </div>






          <div className="admin-card">
            <div className="admin-card-icon" aria-hidden="true">📋</div>
            <h3>
              Booking Management
            </h3>


            <p>
              View and update customer bookings.
            </p>


            <Link to="/admin/bookings">
              Manage Bookings
            </Link>


          </div>




          <div className="admin-card">
            <div className="admin-card-icon" aria-hidden="true">🌍</div>
            <h3>
              Package List
            </h3>


            <p>
              View existing packages.
            </p>


            <Link to="/packages">
              View Packages
            </Link>


          </div>



        </div>


      </main>


    </>

  );

}


export default AdminDashboard;