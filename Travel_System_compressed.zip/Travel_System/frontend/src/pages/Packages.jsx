import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import fallbackPackages from "../data/fallbackPackages";
import "./Packages.css";

const defaultImage =
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80";

function Packages() {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const getPackages = async () => {
    setLoading(true);

    try {
      const response = await API.get("/packages");
      const data = Array.isArray(response.data) ? response.data : [];
      setPackages(data);
      setError("");
    } catch (err) {
      console.error(err);
      setPackages(fallbackPackages);
      setError("");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getPackages();
  }, []);

  return (
    <div className="packages-page">
      <section className="packages-hero">
        <div>
          <p className="section-label">Choose your perfect trip</p>

          <h1>Explore curated tours for every kind of traveler</h1>

          <p>
            From peaceful hill retreats to beachside adventures,
            Vignesh Tours makes every booking feel easy.
          </p>
        </div>
      </section>

      {loading && (
        <div className="status-card">Loading packages...</div>
      )}

      {!loading && packages.length === 0 && (
        <div className="status-card empty">
          No packages available at the moment.
        </div>
      )}

      {!loading && packages.length > 0 && (
        <>
          <h2 className="results-heading">Available Packages</h2>

          <div className="package-container">
            {packages.map((pkg) => {
              const imageUrl =
                pkg.image ||
                pkg.images?.[0] ||
                pkg.gallery?.[0] ||
                defaultImage;

              const priceValue = Number(
                pkg.price ?? pkg.price_per_person ?? 0
              );

              const packageId = pkg._id || pkg.id;

              const description =
                pkg.description && pkg.description.trim().length > 30
                  ? pkg.description
                  : `Experience the beauty of ${pkg.title} with comfortable accommodation, sightseeing, delicious meals and unforgettable memories with Vignesh Tours.`;

              const location =
                pkg.destination ||
                pkg.location ||
                pkg.city ||
                pkg.title;

              return (
                <article
                  className="package-card"
                  key={packageId || pkg.title}
                >
                  <img
                    src={imageUrl}
                    alt={pkg.title}
                    onError={(event) => {
                      event.target.onerror = null;
                      event.target.src = defaultImage;
                    }}
                  />

                  <div className="package-body">
                    <h2>{pkg.title}</h2>

                    <p className="destination">{location}</p>

                    <p className="package-description">
                      {description.length > 150
                        ? description.substring(0, 150) + "..."
                        : description}

                      <Link
                        to={`/packages/${packageId}`}
                        className="details-link"
                      >
                        Details
                      </Link>
                    </p>

                    <div className="package-meta">
                      <div>
                        <span className="price-label">
                          Starting from
                        </span>

                        <strong>
                          Rs {priceValue.toLocaleString("en-IN")}
                        </strong>
                      </div>

                      <span>{pkg.duration || "3 Days"}</span>
                    </div>

                    <Link
                      to={`/packages/${packageId}`}
                      className="book-btn details-btn"
                    >
                      View Details
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

export default Packages;
