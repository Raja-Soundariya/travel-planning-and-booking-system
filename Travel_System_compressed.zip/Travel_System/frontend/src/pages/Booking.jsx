import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import API from "../services/api";
import { getFallbackPackageById } from "../data/fallbackPackages";
import "./Booking.css";

function Booking() {

  const { id } = useParams();
  const navigate = useNavigate();

  const [pkg, setPkg] = useState(null);

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    travellers: 1,
    travelDate: "",
    specialRequest: "",
  });

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [isFallbackPackage, setIsFallbackPackage] = useState(false);

  // =====================================================
  // LOAD RAZORPAY SCRIPT
  // =====================================================

  useEffect(() => {

    const loadRazorpay = () => {

      return new Promise((resolve) => {

        if (window.Razorpay) {
          resolve(true);
          return;
        }

        const script = document.createElement("script");

        script.src =
          "https://checkout.razorpay.com/v1/checkout.js";

        script.onload = () => {
          resolve(true);
        };

        script.onerror = () => {
          resolve(false);
        };

        document.body.appendChild(script);

      });

    };

    loadRazorpay();

  }, []);


  // =====================================================
  // FETCH PACKAGE
  // =====================================================

  useEffect(() => {

    fetchPackage();

  }, [id]);


  const fetchPackage = async () => {

    const fallback = getFallbackPackageById(id);

    try {

      const res = await API.get(`/packages/${id}`);

      const loadedPackage = res.data || fallback || null;
      setPkg(loadedPackage);
      setIsFallbackPackage(Boolean(fallback) && !res.data);

    } catch (err) {

      console.error(err);

      if (fallback) {
        setPkg(fallback);
        setIsFallbackPackage(true);
      } else {
        setIsFallbackPackage(false);
        alert("Unable to load package.");
      }

    } finally {

      setLoading(false);

    }

  };


  // =====================================================
  // HANDLE INPUT
  // =====================================================

  const handleChange = (e) => {

    setFormData((prev) => ({

      ...prev,

      [e.target.name]:
        e.target.name === "travellers"
          ? Number(e.target.value)
          : e.target.value,

    }));

  };


  // =====================================================
  // PRICE CALCULATION
  // =====================================================

  const price =
    pkg?.price ||
    pkg?.price_per_person ||
    0;


  const totalAmount =
    price * formData.travellers;


  // =====================================================
  // CREATE PAYMENT + VERIFY PAYMENT
  // =====================================================

  const handleSubmit = async (e) => {

    e.preventDefault();

    if (!pkg) return;

    if (isFallbackPackage || String(pkg._id || "").startsWith("pkg-")) {
      alert("This package is from demo data and cannot start Razorpay checkout until the database is connected.");
      return;
    }


    try {

      setSubmitting(true);


      // -------------------------------------------------
      // CHECK RAZORPAY
      // -------------------------------------------------

      if (!window.Razorpay) {

        alert(
          "Razorpay failed to load. Please refresh the page and try again."
        );

        setSubmitting(false);

        return;

      }


      // -------------------------------------------------
      // STEP 1: CREATE RAZORPAY ORDER
      // -------------------------------------------------

      const orderResponse = await API.post(
        "/payments/create-order",
        {
          packageId: pkg._id,
          travellers: formData.travellers,
        }
      );


      if (!orderResponse.data.success) {

        throw new Error(
          "Unable to create payment order."
        );

      }


      const order =
        orderResponse.data.order;


      // -------------------------------------------------
      // STEP 2: OPEN RAZORPAY CHECKOUT
      // -------------------------------------------------

      const options = {

        key: orderResponse.data.key,

        amount: order.amount,

        currency: order.currency,

        name: "Vignesh Tours",

        description:
          `${pkg.title} - Tour Booking`,

        order_id: order.id,


        prefill: {

          name: formData.fullName,

          email: formData.email,

          contact: formData.phone,

        },


        notes: {

          packageId: pkg._id,

          travellers:
            String(formData.travellers),

        },


        theme: {

          color: "#2563eb",

        },


        handler: async function (response) {

          try {

            // -------------------------------------------
            // STEP 3: VERIFY PAYMENT
            // -------------------------------------------

            const verifyResponse =
              await API.post(
                "/payments/verify",
                {

                  razorpay_order_id:
                    response.razorpay_order_id,

                  razorpay_payment_id:
                    response.razorpay_payment_id,

                  razorpay_signature:
                    response.razorpay_signature,


                  bookingData: {

                    packageId: pkg._id,

                    fullName:
                      formData.fullName,

                    email:
                      formData.email,

                    phone:
                      formData.phone,

                    travellers:
                      formData.travellers,

                    travelDate:
                      formData.travelDate,

                    specialRequest:
                      formData.specialRequest,

                  },

                }
              );


            // -------------------------------------------
            // PAYMENT VERIFIED
            // -------------------------------------------

            if (
              verifyResponse.data.success
            ) {

              alert(
                "Payment successful! Your booking is confirmed."
              );


              navigate(
                `/booking-success/${verifyResponse.data.booking._id}`
              );

            } else {

              alert(
                "Payment verification failed."
              );

            }

          } catch (err) {

            console.error(
              "Payment verification error:",
              err
            );


            alert(
              err.response?.data?.message ||
              "Payment verification failed."
            );

          } finally {

            setSubmitting(false);

          }

        },


        modal: {

          ondismiss: function () {

            setSubmitting(false);

            alert(
              "Payment was cancelled."
            );

          },

        },

      };


      // -------------------------------------------------
      // STEP 4: OPEN RAZORPAY
      // -------------------------------------------------

      const razorpay =
        new window.Razorpay(options);


      razorpay.on(
        "payment.failed",
        function (response) {

          console.error(
            "Payment failed:",
            response.error
          );


          setSubmitting(false);


          alert(
            response.error?.description ||
            "Payment failed. Please try again."
          );

        }
      );


      razorpay.open();


    } catch (err) {

      console.error(
        "Payment error:",
        err
      );


      alert(
        err.response?.data?.message ||
        err.message ||
        "Unable to start payment."
      );


      setSubmitting(false);

    }

  };


  // =====================================================
  // LOADING
  // =====================================================

  if (loading) {

    return (

      <div className="status-card">

        Loading Package...

      </div>

    );

  }


  // =====================================================
  // PACKAGE NOT FOUND
  // =====================================================

  if (!pkg) {

    return (

      <div className="status-card error">

        Package not found.

      </div>

    );

  }


  // =====================================================
  // UI
  // =====================================================

  return (

    <div className="packages-page">


      {/* HERO */}

      <section className="packages-hero">

        <p className="section-label">
          Book Your Trip
        </p>


        <h1>
          {pkg.title}
        </h1>


        <p>
          Complete your booking details below.
        </p>

      </section>


      <div className="detail-card">


        {/* PACKAGE SUMMARY */}

        <div className="package-card">


          <img

            src={
              pkg.image ||
              pkg.images?.[0] ||
              pkg.gallery?.[0] ||
              "/default-tour.jpg"
            }

            alt={pkg.title}

          />


          <div className="package-body">


            <h2>
              {pkg.title}
            </h2>


            <p>
              📍 {pkg.destination || "Tour Package"}
            </p>


            <div className="package-meta">


              <div>

                <span className="price-label">

                  Price / Person

                </span>


                <strong>

                  ₹{" "}

                  {price.toLocaleString(
                    "en-IN"
                  )}

                </strong>

              </div>


              <span>
                {pkg.duration}
              </span>


            </div>


            <hr />


            <h3>
              Total Amount
            </h3>


            <h2
              style={{
                color: "#2563eb"
              }}
            >

              ₹{" "}

              {totalAmount.toLocaleString(
                "en-IN"
              )}

            </h2>


          </div>

        </div>


        {/* BOOKING FORM */}

        <form

          className="booking-form"

          onSubmit={handleSubmit}

        >


          <h2>
            Traveller Details
          </h2>


          <input

            type="text"

            name="fullName"

            placeholder="Full Name"

            value={formData.fullName}

            onChange={handleChange}

            required

          />


          <input

            type="email"

            name="email"

            placeholder="Email Address"

            value={formData.email}

            onChange={handleChange}

            required

          />


          <input

            type="tel"

            name="phone"

            placeholder="Phone Number"

            value={formData.phone}

            onChange={handleChange}

            required

          />


          <input

            type="date"

            name="travelDate"

            value={formData.travelDate}

            onChange={handleChange}

            required

          />


          <input

            type="number"

            name="travellers"

            min="1"

            value={formData.travellers}

            onChange={handleChange}

            required

          />


          <textarea

            name="specialRequest"

            placeholder="Special Requests (Optional)"

            rows="4"

            value={formData.specialRequest}

            onChange={handleChange}

          />


          <button

            type="submit"

            className="book-btn"

            disabled={submitting}

          >

            {

              submitting

                ? "Processing Payment..."

                : `Pay ₹${totalAmount.toLocaleString(
                    "en-IN"
                  )}`

            }

          </button>


        </form>


      </div>


    </div>

  );

}


export default Booking;

