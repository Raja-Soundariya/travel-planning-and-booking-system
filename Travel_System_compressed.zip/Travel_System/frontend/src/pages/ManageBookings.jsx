import { useEffect, useMemo, useState } from "react";
import AdminNavbar from "../components/AdminNavbar";
import API from "../services/api";
import "./ManageBookings.css";

const bookingStatuses = ["Pending", "Confirmed", "Cancelled"];
const paymentStatuses = ["Pending", "Paid", "Failed"];

function ManageBookings() {
    const [bookings, setBookings] = useState([]);
    const [filter, setFilter] = useState("All");
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [updatingId, setUpdatingId] = useState("");

    const loadBookings = async () => {
        try {
            setLoading(true);
            setError("");
            const response = await API.get("/bookings");
            setBookings(response.data.bookings || []);
        } catch (err) {
            setError(err.response?.data?.message || "Unable to load bookings.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadBookings();
    }, []);

    const visibleBookings = useMemo(() => {
        const query = search.trim().toLowerCase();

        return bookings.filter((booking) => {
            const matchesStatus = filter === "All" || booking.bookingStatus === filter;
            const matchesSearch = !query || [
                booking.fullName,
                booking.email,
                booking.phone,
                booking.packageName,
            ].some((value) => value?.toLowerCase().includes(query));

            return matchesStatus && matchesSearch;
        });
    }, [bookings, filter, search]);

    const updateBooking = async (id, changes) => {
        try {
            setUpdatingId(id);
            const response = await API.put(`/bookings/${id}`, changes);
            setBookings((current) => current.map((booking) => (
                booking._id === id ? response.data.booking : booking
            )));
        } catch (err) {
            setError(err.response?.data?.message || "Unable to update booking.");
        } finally {
            setUpdatingId("");
        }
    };

    const deleteBooking = async (id) => {
        if (!window.confirm("Delete this booking permanently?")) return;

        try {
            setUpdatingId(id);
            await API.delete(`/bookings/${id}`);
            setBookings((current) => current.filter((booking) => booking._id !== id));
        } catch (err) {
            setError(err.response?.data?.message || "Unable to delete booking.");
        } finally {
            setUpdatingId("");
        }
    };

    return (
        <>
            <AdminNavbar />
            <main className="manage-bookings">
                <div className="manage-bookings-header">
                    <div>
                        <p className="eyebrow">ADMINISTRATION</p>
                        <h1>Manage Bookings</h1>
                        <p>Review customer requests and keep booking statuses up to date.</p>
                    </div>
                    <button className="refresh-button" onClick={loadBookings} disabled={loading}>
                        Refresh
                    </button>
                </div>

                <div className="booking-toolbar">
                    <input
                        type="search"
                        placeholder="Search customer, email, or package"
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                    />
                    <select value={filter} onChange={(event) => setFilter(event.target.value)}>
                        <option value="All">All statuses</option>
                        {bookingStatuses.map((status) => <option key={status} value={status}>{status}</option>)}
                    </select>
                </div>

                {error && <p className="booking-error">{error}</p>}
                {loading && <p className="booking-empty">Loading bookings...</p>}
                {!loading && !visibleBookings.length && <p className="booking-empty">No bookings match your search.</p>}

                {!loading && visibleBookings.length > 0 && (
                    <div className="booking-table-wrap">
                        <table className="booking-table">
                            <thead>
                                <tr><th>Customer</th><th>Package & date</th><th>Travellers</th><th>Total</th><th>Booking status</th><th>Payment</th><th /></tr>
                            </thead>
                            <tbody>
                                {visibleBookings.map((booking) => (
                                    <tr key={booking._id}>
                                        <td><strong>{booking.fullName}</strong><span>{booking.email}</span><span>{booking.phone}</span></td>
                                        <td><strong>{booking.packageName}</strong><span>{new Date(booking.travelDate).toLocaleDateString()}</span></td>
                                        <td>{booking.travellers}</td>
                                        <td>₹{Number(booking.totalAmount || 0).toLocaleString("en-IN")}</td>
                                        <td><select value={booking.bookingStatus} disabled={updatingId === booking._id} onChange={(event) => updateBooking(booking._id, { bookingStatus: event.target.value })}>{bookingStatuses.map((status) => <option key={status}>{status}</option>)}</select></td>
                                        <td><select value={booking.paymentStatus} disabled={updatingId === booking._id} onChange={(event) => updateBooking(booking._id, { paymentStatus: event.target.value })}>{paymentStatuses.map((status) => <option key={status}>{status}</option>)}</select></td>
                                        <td><button className="delete-button" disabled={updatingId === booking._id} onClick={() => deleteBooking(booking._id)}>Delete</button></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </main>
        </>
    );
}

export default ManageBookings;