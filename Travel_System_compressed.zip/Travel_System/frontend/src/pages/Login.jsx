import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../services/api";
import "./Auth.css";


function Login() {

  const navigate = useNavigate();


  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });


  const [message, setMessage] = useState({
    type: "",
    text: ""
  });


  const [loading, setLoading] = useState(false);



  const handleChange = (e) => {

    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value
    }));

  };




  const handleSubmit = async (e) => {

    e.preventDefault();


    setLoading(true);

    setMessage({
      type: "",
      text: ""
    });



    try {

      const response = await API.post(
        "/auth/login",
        formData
      );


      // Save JWT token
      localStorage.setItem(
        "token",
        response.data.token
      );


      // Save user details including role
      localStorage.setItem(
        "user",
        JSON.stringify(response.data.user)
      );


      setMessage({

        type: "success",

        text:
          response.data.message ||
          "Login successful"

      });


      // Redirect based on role
      if (response.data.user.role === "admin") {

        navigate("/admin/dashboard");

      }
      else {

        navigate("/packages");

      }



    } catch (error) {

      setMessage({

        type: "error",

        text:
          error.response?.data?.message ||
          "Login failed. Please try again."

      });

    } finally {

      setLoading(false);

    }

  };




  return (

    <div className="auth-page">


      <div className="auth-card">


        <p className="auth-kicker">
          Welcome back
        </p>


        <h1>
          Login to your account
        </h1>


        <p className="auth-subtitle">
          Continue planning your next trip with your saved preferences.
        </p>




        <form
          className="auth-form"
          onSubmit={handleSubmit}
        >


          <label className="auth-field">

            <span>
              Email
            </span>


            <input
              type="email"
              name="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={handleChange}
              required
            />

          </label>




          <label className="auth-field">

            <span>
              Password
            </span>


            <input
              type="password"
              name="password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              required
            />

          </label>



          {/* Forgot Password */}

          <div className="forgot-password-link">

            <Link to="/forgot-password">
              Forgot Password?
            </Link>

          </div>




          {
            message.text && (

              <div
                className={`auth-message ${message.type}`}
              >

                {message.text}

              </div>

            )
          }




          <button
            className="auth-button"
            type="submit"
            disabled={loading}
          >

            {
              loading
                ? "Signing in..."
                : "Login"
            }

          </button>


        </form>




        <p className="auth-footer">

          New here?

          {" "}

          <Link to="/register">
            Create an account
          </Link>

        </p>



      </div>


    </div>

  );

}


export default Login;