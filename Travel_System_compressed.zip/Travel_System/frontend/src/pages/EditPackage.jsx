import AdminNavbar from "../components/AdminNavbar";
import { useParams } from "react-router-dom";


function EditPackage() {


 const { id } = useParams();


 return (

   <>

    <AdminNavbar />


    <h1>
      Edit Package
    </h1>


    <p>
      Package ID: {id}
    </p>


   </>

 );


}


export default EditPackage;