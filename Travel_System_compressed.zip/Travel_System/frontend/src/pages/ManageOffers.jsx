import { useState } from "react";
import AdminNavbar from "../components/AdminNavbar";
import "./ManageOffers.css";

function ManageOffers() {
  const [offer, setOffer] = useState({ title: "", code: "", discount: "", expires: "", description: "" });
  const [offers, setOffers] = useState([]);
  const handleChange = (event) => setOffer((current) => ({ ...current, [event.target.name]: event.target.value }));
  const addOffer = (event) => {
    event.preventDefault();
    setOffers((current) => [{ ...offer, id: Date.now() }, ...current]);
    setOffer({ title: "", code: "", discount: "", expires: "", description: "" });
  };

  return (
    <>
      <AdminNavbar />
      <main className="offers-page">
        <section className="offers-hero"><div><span className="section-label">PROMOTIONS</span><h1>Manage offers</h1><p>Create attractive deals to help travellers discover their next adventure.</p></div><span className="offers-hero-icon">🎁</span></section>
        <div className="offers-layout">
          <form className="offer-form" onSubmit={addOffer}>
            <div className="offer-form-heading"><span>✨</span><div><h2>Create an offer</h2><p>Fill in the details below to preview your promotion.</p></div></div>
            <label>Offer title<input name="title" value={offer.title} onChange={handleChange} placeholder="Summer escape sale" required /></label>
            <div className="offer-grid"><label>Promo code<input name="code" value={offer.code} onChange={handleChange} placeholder="SUMMER25" required /></label><label>Discount<input type="number" min="1" max="100" name="discount" value={offer.discount} onChange={handleChange} placeholder="25" required /></label><label>Valid until<input type="date" name="expires" value={offer.expires} onChange={handleChange} required /></label></div>
            <label>Description<textarea name="description" rows="4" value={offer.description} onChange={handleChange} placeholder="Tell customers what makes this deal special." /></label>
            <button className="offer-submit" type="submit">Publish offer <span>→</span></button>
          </form>
          <aside className="offer-preview"><span className="preview-label">OFFER PREVIEW</span><div className="coupon"><div className="coupon-discount">{offer.discount || "25"}<small>% OFF</small></div><div><strong>{offer.title || "Your special offer"}</strong><p>{offer.description || "A little extra value for your next journey."}</p><b>{offer.code || "PROMO CODE"}</b></div></div><p className="offer-note">Offers are currently shown as a visual preview. Connect an offers API later to persist them in the database.</p></aside>
        </div>
        {offers.length > 0 && <section className="created-offers"><h2>Created this session</h2><div className="offer-list">{offers.map((item) => <article className="mini-offer" key={item.id}><strong>{item.title}</strong><span>{item.discount}% off · {item.code}</span></article>)}</div></section>}
      </main>
    </>
  );
}

export default ManageOffers;
