import { useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import axios from "axios";
import "./ResetPassword.css";

function ResetPassword() {

    const { token } = useParams();

    const navigate = useNavigate();


    const [password, setPassword] = useState("");

    const [confirmPassword, setConfirmPassword] =
        useState("");

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");

    const [loading, setLoading] = useState(false);


    const handleSubmit = async (e) => {

        e.preventDefault();

        setMessage("");
        setError("");


        // Check password
        if (!password) {

            setError("Please enter a new password.");
            return;

        }


        // Minimum password length
        if (password.length < 6) {

            setError(
                "Password must be at least 6 characters."
            );

            return;

        }


        // Confirm password
        if (password !== confirmPassword) {

            setError(
                "Passwords do not match."
            );

            return;

        }


        try {

            setLoading(true);


            const response = await axios.post(

                `http://localhost:5000/api/auth/reset-password/${token}`,

                {
                    password
                }

            );


            setMessage(response.data.message);


            setPassword("");
            setConfirmPassword("");


            // Redirect to login after 2 seconds
            setTimeout(() => {

                navigate("/login");

            }, 2000);


        } catch (error) {

            setError(

                error.response?.data?.message ||

                "Unable to reset password. Please try again."

            );

        } finally {

            setLoading(false);

        }

    };


    return (

        <div className="reset-password-page">

            <div className="reset-password-card">

                <div className="reset-password-header">

                    <h1>
                        Reset Password
                    </h1>

                    <p>
                        Create a new password for your account.
                    </p>

                </div>


                <form onSubmit={handleSubmit}>


                    <div className="form-group">

                        <label>
                            New Password
                        </label>

                        <input
                            type="password"
                            placeholder="Enter new password"
                            value={password}
                            onChange={(e) =>
                                setPassword(e.target.value)
                            }
                        />

                    </div>


                    <div className="form-group">

                        <label>
                            Confirm Password
                        </label>

                        <input
                            type="password"
                            placeholder="Confirm new password"
                            value={confirmPassword}
                            onChange={(e) =>
                                setConfirmPassword(
                                    e.target.value
                                )
                            }
                        />

                    </div>


                    {message && (

                        <div className="success-message">
                            {message}
                        </div>

                    )}


                    {error && (

                        <div className="error-message">
                            {error}
                        </div>

                    )}


                    <button
                        type="submit"
                        disabled={loading}
                    >

                        {loading
                            ? "Resetting..."
                            : "Reset Password"
                        }

                    </button>


                </form>


                <div className="back-to-login">

                    <Link to="/login">
                        ← Back to Login
                    </Link>

                </div>

            </div>

        </div>

    );

}

export default ResetPassword;