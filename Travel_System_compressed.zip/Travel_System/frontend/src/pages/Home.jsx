import { Link } from "react-router-dom";
import "./Home.css";

const destinations = [
  {
    title: "Ooty",
    description: "Misty hills, tea gardens, and cozy weather for a relaxing getaway.",
    image:
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "Kerala",
    description: "Cruise through backwaters and enjoy wellness retreats in the greens.",
    image:
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "Goa",
    description: "Sun-kissed beaches, nightlife, and island-style adventure await.",
    image:
      "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=900&q=80",
  },
];

const features = [
  {
    title: "Handpicked Itineraries",
    text: "Every journey is designed to balance comfort, culture, and unforgettable views.",
  },
  {
    title: "Flexible Planning",
    text: "Choose from weekend escapes to dreamy long vacations with our friendly guidance.",
  },
  {
    title: "24/7 Support",
    text: "From booking help to travel updates, we stay with you from start to finish.",
  },
];

function Home() {
  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-content">
          <p className="hero-badge">Trusted by 10k+ happy travelers</p>
          <h1>Discover your next unforgettable escape with Vignesh Tours</h1>
          <p className="hero-copy">
            Experience curated destinations, seamless bookings, and travel memories that stay with you.
          </p>

          <div className="hero-actions">
            <Link to="/packages" className="primary-btn">
              Explore Packages
            </Link>
            <Link to="/register" className="secondary-btn">
              Create Account
            </Link>
          </div>

          <div className="hero-stats">
            <div>
              <strong>50+</strong>
              <span>Destinations</span>
            </div>
            <div>
              <strong>4.9/5</strong>
              <span>Traveler Rating</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>Support</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <p className="section-label">Popular escapes</p>
          <h2>Where travelers love to go</h2>
        </div>

        <div className="card-grid">
          {destinations.map((destination) => (
            <article className="info-card" key={destination.title}>
              <img src={destination.image} alt={destination.title} />
              <div className="card-body">
                <h3>{destination.title}</h3>
                <p>{destination.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section-block feature-section">
        <div className="section-heading">
          <p className="section-label">Why choose us</p>
          <h2>Travel with confidence and ease</h2>
        </div>

        <div className="card-grid feature-grid">
          {features.map((feature) => (
            <article className="feature-card" key={feature.title}>
              <h3>{feature.title}</h3>
              <p>{feature.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section-block cta-section">
        <div>
          <p className="section-label">Ready to plan?</p>
          <h2>Let’s turn your travel dream into a beautifully organized trip.</h2>
        </div>
        <Link to="/packages" className="primary-btn">
          View Tour Packages
        </Link>
      </section>
    </div>
  );
}

export default Home;