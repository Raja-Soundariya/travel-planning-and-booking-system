import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import API from "../services/api";
import { getFallbackPackageById } from "../data/fallbackPackages";
import "./Packages.css";

const defaultImage =
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80";


function PackageDetails() {

  const { id } = useParams();

  const [pkg, setPkg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedImage, setSelectedImage] = useState(null);



  useEffect(() => {

    const fetchPackage = async () => {

      const fallback = getFallbackPackageById(id);


      try {

        setLoading(true);


        const res = await API.get(
          `/packages/${id}`
        );


        setPkg(
          res.data ||
          fallback ||
          null
        );


        setError("");


      } catch (err) {

        console.error(err);


        if (fallback) {

          setPkg(fallback);
          setError("");

        } else {

          setError(
            "Could not load package details."
          );

        }


      } finally {

        setLoading(false);

      }

    };


    if (id) {

      fetchPackage();

    }


  }, [id]);





  if (loading) {

    return (

      <div className="status-card">

        Loading package...

      </div>

    );

  }





  if (error) {

    return (

      <div className="status-card error">

        {error}

      </div>

    );

  }





  if (!pkg) {

    return (

      <div className="status-card">

        Package not found.

      </div>

    );

  }





  let imageUrl =
    pkg.image ||
    pkg.images?.[0] ||
    pkg.gallery?.[0] ||
    defaultImage;



  let gallery =
    pkg.gallery?.length
      ? [...pkg.gallery]
      : pkg.images?.length
      ? [...pkg.images]
      : [imageUrl];






  // Ooty custom images

  if (
    pkg.title?.toLowerCase()
    .includes("ooty")
  ) {


    imageUrl =
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80";



    gallery = [

      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",

      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=80",

      "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=900&q=80",

      "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=900&q=80"

    ];

  }





  const description =
    pkg.description ||
    `Experience the beauty of ${pkg.title} with comfortable accommodation, sightseeing, delicious meals, scenic attractions and unforgettable memories with Vignesh Tours.`;





  const inclusions =
    pkg.inclusions?.length
      ? pkg.inclusions
      : [

        "Hotel Accommodation",

        "Daily Breakfast",

        "Sightseeing",

        "Transportation",

        "Professional Tour Guide"

      ];





  const exclusions =
    pkg.exclusions?.length
      ? pkg.exclusions
      : [

        "Flight / Train Tickets",

        "Personal Expenses",

        "Travel Insurance"

      ];





  const experiences =
    pkg.experiences?.length
      ? pkg.experiences
      : [

        "Beautiful sightseeing with breathtaking landscapes.",

        "Comfortable hotel stay with quality service.",

        "A memorable holiday with Vignesh Tours."

      ];





  const priceValue = Number(

    pkg.price ??
    pkg.price_per_person ??
    0

  );




  return (

    <div className="packages-page">



      <section className="packages-hero">

        <div>

          <p className="section-label">

            Package Details

          </p>


          <h1>

            {pkg.title}

          </h1>


          <p>

            📍 {pkg.destination || pkg.title}

          </p>


        </div>


      </section>





      <article className="package-card detail-card">



        <img

          src={imageUrl}

          alt={pkg.title}

          onError={(e)=>{

            e.target.src = defaultImage;

          }}

        />





        <div className="package-body">



          <h2>

            {pkg.title}

          </h2>





          <p className="full-desc">

            {description}

          </p>





          <div className="section">


            <h3>

              Inclusions

            </h3>


            <ul>

              {
                inclusions.map(
                  (item,index)=>(
                    <li key={index}>
                      {item}
                    </li>
                  )
                )
              }

            </ul>


          </div>





          <div className="section">


            <h3>

              Exclusions

            </h3>


            <ul>

              {
                exclusions.map(
                  (item,index)=>(
                    <li key={index}>
                      {item}
                    </li>
                  )
                )
              }

            </ul>


          </div>






          <div className="section">


            <h3>

              Gallery

            </h3>



            <div className="gallery">


              {
                gallery.map(
                  (img,index)=>(

                    <img

                      key={index}

                      src={img}

                      alt={`${pkg.title}-${index}`}

                      className="thumb"

                      onClick={()=>setSelectedImage(img)}

                    />

                  )
                )
              }


            </div>


          </div>







          <div className="experiences">


            <h3>

              Previous Experiences

            </h3>



            {
              experiences.map(
                (exp,index)=>(

                  <div

                    className="experience"

                    key={index}

                  >

                    {exp}

                  </div>

                )
              )
            }



          </div>







          <div className="package-meta">


            <div>


              <span className="price-label">

                Starting from

              </span>



              <strong>

                ₹{" "}

                {
                  priceValue.toLocaleString(
                    "en-IN"
                  )
                }


              </strong>


            </div>





            <span>

              {
                pkg.duration ||
                "3 Days"
              }


            </span>



          </div>







          <div className="details-actions">


            <Link

              to={`/booking/${pkg._id || pkg.id}`}

              className="book-btn"

            >

              Reserve Now

            </Link>





            <Link

              to="/packages"

              className="book-btn"

            >

              ← Back to Packages

            </Link>


          </div>





        </div>



      </article>







      {
        selectedImage && (

          <div

            className="modal-overlay"

            onClick={()=>
              setSelectedImage(null)
            }

          >

            <img

              src={selectedImage}

              alt="Selected"

              className="modal-image"

            />

          </div>

        )
      }



    </div>

  );

}



export default PackageDetails;