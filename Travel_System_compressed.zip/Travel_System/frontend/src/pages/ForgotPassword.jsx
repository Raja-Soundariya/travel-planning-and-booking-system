import { useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import "./ForgotPassword.css";


function ForgotPassword() {

    const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);


    const handleSubmit = async (e) => {

        e.preventDefault();

        setMessage("");
        setError("");


        if (!email) {

            setError("Please enter your email address.");
            return;

        }


        try {

            setLoading(true);


            const response = await API.post(
                "/auth/forgot-password",
                {
                    email
                }
            );


            setMessage(response.data.message);

            setEmail("");


        } catch (error) {

            console.error(
                "Forgot Password Error:",
                error
            );


            setError(
                error.response?.data?.message ||
                "Something went wrong. Please try again."
            );


        } finally {

            setLoading(false);

        }

    };


    return (

        <div className="forgot-password-page">

            <div className="forgot-password-card">

                <div className="forgot-password-header">

                    <h1>
                        Forgot Password?
                    </h1>

                    <p>
                        Enter your registered email address and
                        we'll send you a password reset link.
                    </p>

                </div>


                <form onSubmit={handleSubmit}>

                    <div className="form-group">

                        <label>
                            Email Address
                        </label>


                        <input
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) =>
                                setEmail(e.target.value)
                            }
                            required
                        />

                    </div>


                    {message && (

                        <div className="success-message">
                            {message}
                        </div>

                    )}


                    {error && (

                        <div className="error-message">
                            {error}
                        </div>

                    )}


                    <button
                        type="submit"
                        disabled={loading}
                    >

                        {loading
                            ? "Sending..."
                            : "Send Reset Link"
                        }

                    </button>

                </form>


                <div className="back-to-login">

                    <Link to="/login">
                        ← Back to Login
                    </Link>

                </div>

            </div>

        </div>

    );

}


export default ForgotPassword;