import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminNavbar from "../components/AdminNavbar";
import API from "../services/api";
import "./AddPackage.css";

const initialForm = {
  title: "", destination: "", duration: "", duration_days: "", price: "",
  category: "Domestic", image: "", max_seats: "", description: "",
};

function AddPackage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState(initialForm);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  const handleChange = (event) => {
    setFormData((current) => ({ ...current, [event.target.name]: event.target.value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setMessage({ type: "", text: "" });
    try {
      await API.post("/packages", {
        ...formData,
        price: Number(formData.price),
        duration_days: Number(formData.duration_days || 0),
        max_seats: Number(formData.max_seats || 0),
        available_seats: Number(formData.max_seats || 0),
      });
      setMessage({ type: "success", text: "Package added successfully." });
      setTimeout(() => navigate("/admin/dashboard"), 1000);
    } catch (error) {
      setMessage({ type: "error", text: error.response?.data?.message || "Failed to add package." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AdminNavbar />
      <main className="add-package-page">
        <section className="form-hero">
          <div><span className="section-label">PACKAGE MANAGEMENT</span><h1>Create a new journey</h1><p>Build an inspiring package your customers will love to explore.</p></div>
          <span className="form-hero-icon">✈️</span>
        </section>

        <div className="package-form-layout">
          <form className="package-form" onSubmit={handleSubmit}>
            <div className="form-section"><h2>Package details</h2><p>Start with the essentials for your tour listing.</p>
              <div className="form-grid">
                <label>Package title<input name="title" placeholder="e.g. Kerala Backwater Escape" value={formData.title} onChange={handleChange} required /></label>
                <label>Destination<input name="destination" placeholder="e.g. Munnar, Kerala" value={formData.destination} onChange={handleChange} required /></label>
                <label>Duration<input name="duration" placeholder="e.g. 5 Days / 4 Nights" value={formData.duration} onChange={handleChange} required /></label>
                <label>Duration in days<input type="number" min="1" name="duration_days" placeholder="5" value={formData.duration_days} onChange={handleChange} /></label>
                <label>Price per traveller (₹)<input type="number" min="0" name="price" placeholder="25000" value={formData.price} onChange={handleChange} required /></label>
                <label>Maximum seats<input type="number" min="1" name="max_seats" placeholder="20" value={formData.max_seats} onChange={handleChange} /></label>
                <label>Category<select name="category" value={formData.category} onChange={handleChange}><option>Domestic</option><option>International</option><option>Adventure</option><option>Family</option><option>Honeymoon</option></select></label>
                <label>Cover image URL<input name="image" placeholder="https://..." value={formData.image} onChange={handleChange} /></label>
              </div>
              <label>Description<textarea name="description" rows="5" placeholder="Describe the experience, stay, and highlights..." value={formData.description} onChange={handleChange} required /></label>
            </div>
            {message.text && <p className={`form-message ${message.type}`}>{message.text}</p>}
            <div className="form-actions"><button type="button" className="cancel-button" onClick={() => navigate("/admin/dashboard")}>Cancel</button><button className="submit-button" type="submit" disabled={saving}>{saving ? "Saving..." : "Publish Package"}</button></div>
          </form>

          <aside className="package-preview">
            <span className="preview-label">LIVE PREVIEW</span>
            <div className="preview-image" style={formData.image ? { backgroundImage: `url(${formData.image})` } : undefined}><span>🌴</span></div>
            <div className="preview-content"><span className="preview-category">{formData.category}</span><h2>{formData.title || "Your package title"}</h2><p>{formData.destination || "Destination"} · {formData.duration || "Duration"}</p><div className="preview-price">₹{Number(formData.price || 0).toLocaleString("en-IN")} <small>/ traveller</small></div><p className="preview-description">{formData.description || "Your package description will appear here."}</p></div>
          </aside>
        </div>
      </main>
    </>
  );
}

export default AddPackage;
