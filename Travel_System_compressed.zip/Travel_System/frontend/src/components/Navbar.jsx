import { useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import "./Navbar.css";

function Navbar() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(Boolean(localStorage.getItem("token")));
  const [isAdmin, setIsAdmin] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("user"))?.role === "admin";
    } catch {
      return false;
    }
  });

  useEffect(() => {
    setIsLoggedIn(Boolean(localStorage.getItem("token")));
    try {
      setIsAdmin(JSON.parse(localStorage.getItem("user"))?.role === "admin");
    } catch {
      setIsAdmin(false);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setIsLoggedIn(false);
    setIsAdmin(false);
    navigate("/");
  };

  return (
    <nav className="navbar">
      <Link to="/" className="logo">
        ✈️ Vignesh Tours
      </Link>

      <ul className="nav-links">
        <li>
          <NavLink to="/" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
            Home
          </NavLink>
        </li>
        <li>
          <NavLink to="/packages" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
            Packages
          </NavLink>
        </li>
        {isAdmin && (
          <li>
            <NavLink to="/admin/dashboard" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
              Admin Dashboard
            </NavLink>
          </li>
        )}
        {isLoggedIn ? (
          <li>
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </li>
        ) : (
          <>
            <li>
              <NavLink to="/login" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                Login
              </NavLink>
            </li>
            <li>
              <NavLink to="/register" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                Register
              </NavLink>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
}

export default Navbar;