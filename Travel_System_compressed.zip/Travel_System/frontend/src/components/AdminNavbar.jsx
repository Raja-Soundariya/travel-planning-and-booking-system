import { Link, useNavigate } from "react-router-dom";
import "./AdminNavbar.css";

function AdminNavbar() {

  const navigate = useNavigate();


  const handleLogout = () => {

    localStorage.removeItem("token");
    localStorage.removeItem("user");

    navigate("/login");

  };


  return (

    <nav className="admin-navbar">

      <div className="admin-logo">
        Vignesh Tours Admin
      </div>


      <div className="admin-links">

        <Link to="/admin/dashboard">
          Dashboard
        </Link>


        <Link to="/admin/add-package">
          Add Package
        </Link>


        <Link to="/admin/offers">
          Manage Offers
        </Link>


        <Link to="/admin/bookings">
          Bookings
        </Link>


        <button
          className="admin-logout"
          onClick={handleLogout}
        >
          Logout
        </button>


      </div>


    </nav>

  );

}


export default AdminNavbar;