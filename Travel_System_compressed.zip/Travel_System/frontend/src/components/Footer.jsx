import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div>
          <h3>Vignesh Tours</h3>
          <p>Curated travel experiences that feel effortless from the first click.</p>
        </div>
        <div>
          <h4>Contact</h4>
          <p>vigneshadmin86@gmail.com</p>
          <p>+91 9626903297</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
