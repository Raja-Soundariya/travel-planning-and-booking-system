import { Navigate } from "react-router-dom";


function AdminRoute({ children }) {
    let user = null;

    try {
        user = JSON.parse(localStorage.getItem("user"));
    } catch {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
    }


    // User not logged in
    if (!user) {

        return <Navigate to="/login" />;

    }



    // Logged in but not admin
    if (user.role !== "admin") {

        return <Navigate to="/" />;

    }



    // Admin allowed
    return children;

}


export default AdminRoute;