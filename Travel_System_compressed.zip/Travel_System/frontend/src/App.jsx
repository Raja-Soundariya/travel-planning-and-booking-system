import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AdminRoute from "./components/AdminRoute";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";

import Packages from "./pages/Packages";
import PackageDetails from "./pages/PackageDetails";
import Booking from "./pages/Booking";
import BookingSuccess from "./pages/BookingSuccess";

// Admin Pages
import AdminDashboard from "./pages/AdminDashboard";
import AddPackage from "./pages/AddPackage";
import EditPackage from "./pages/EditPackage";
import ManageOffers from "./pages/ManageOffers";
import ManageBookings from "./pages/ManageBookings";

import "./App.css";


function App() {

    return (

        <BrowserRouter>

            <Routes>

                {/* =====================
                    USER SIDE ROUTES
                ====================== */}

                <Route
                    path="/"
                    element={
                        <>
                            <Navbar />
                            <Home />
                            <Footer />
                        </>
                    }
                />


                <Route
                    path="/login"
                    element={
                        <>
                            <Navbar />
                            <Login />
                            <Footer />
                        </>
                    }
                />


                <Route
                    path="/register"
                    element={
                        <>
                            <Navbar />
                            <Register />
                            <Footer />
                        </>
                    }
                />


                {/* =====================
                    FORGOT PASSWORD
                ====================== */}

                <Route
                    path="/forgot-password"
                    element={
                        <>
                            <Navbar />
                            <ForgotPassword />
                            <Footer />
                        </>
                    }
                />


                {/* =====================
                    RESET PASSWORD
                ====================== */}

                <Route
                    path="/reset-password/:token"
                    element={
                        <>
                            <Navbar />
                            <ResetPassword />
                            <Footer />
                        </>
                    }
                />


                <Route
                    path="/packages"
                    element={
                        <>
                            <Navbar />
                            <Packages />
                            <Footer />
                        </>
                    }
                />


                <Route
                    path="/packages/:id"
                    element={
                        <>
                            <Navbar />
                            <PackageDetails />
                            <Footer />
                        </>
                    }
                />


                <Route
                    path="/booking/:id"
                    element={
                        <>
                            <Navbar />
                            <Booking />
                            <Footer />
                        </>
                    }
                />


                <Route
                    path="/booking-success/:id"
                    element={
                        <>
                            <Navbar />
                            <BookingSuccess />
                            <Footer />
                        </>
                    }
                />


                {/* =====================
                    ADMIN SIDE ROUTES
                ====================== */}

                <Route
                    path="/admin/dashboard"
                    element={
                        <AdminRoute>
                            <AdminDashboard />
                        </AdminRoute>
                    }
                />


                <Route
                    path="/admin/add-package"
                    element={
                        <AdminRoute>
                            <AddPackage />
                        </AdminRoute>
                    }
                />


                <Route
                    path="/admin/edit-package/:id"
                    element={
                        <AdminRoute>
                            <EditPackage />
                        </AdminRoute>
                    }
                />


                <Route
                    path="/admin/offers"
                    element={
                        <AdminRoute>
                            <ManageOffers />
                        </AdminRoute>
                    }
                />


                <Route
                    path="/admin/bookings"
                    element={
                        <AdminRoute>
                            <ManageBookings />
                        </AdminRoute>
                    }
                />

            </Routes>

        </BrowserRouter>

    );

}


export default App;