const fallbackPackages = [
  {
    _id: "pkg-ooty",
    title: "Ooty Hills Retreat",
    description: "Enjoy scenic viewpoints, tea estates, and cool mountain air in a cozy escape.",
    destination: "Ooty, Tamil Nadu",
    price: 8999,
    duration: "3 Days / 2 Nights",
    image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80"
    ],
    inclusions: ["Comfort stay", "Local sightseeing", "Breakfast", "Airport pickup"],
    exclusions: ["Flight tickets", "Dinner", "Personal expenses"],
    payment_modes: ["UPI", "Card", "Cash"],
    experiences: ["Scenic viewpoints", "Tea estate visit", "Botanical gardens"],
  },
  {
    _id: "pkg-kerala",
    title: "Kerala Backwater Bliss",
    description: "Relax on houseboats and explore nature, cuisine, and calm waters.",
    destination: "Kerala",
    price: 12999,
    duration: "4 Days / 3 Nights",
    image: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1512100356356-de1b84283e18?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80"
    ],
    inclusions: ["Houseboat stay", "Meals", "Transfers", "Guided tour"],
    exclusions: ["Flights", "Shopping", "Spa services"],
    payment_modes: ["UPI", "Card"],
    experiences: ["Houseboat cruise", "Backwater village visit", "Ayurveda spa"],
  },
  {
    _id: "pkg-goa",
    title: "Goa Beach Retreat",
    description: "A sunny beach holiday with watersports, sunsets, and vibrant evenings.",
    destination: "Goa",
    price: 10999,
    duration: "5 Days / 4 Nights",
    image: "https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1493558103817-58b2924bce98?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80"
    ],
    inclusions: ["Beachfront stay", "Water sports", "Breakfast", "Airport transfer"],
    exclusions: ["Flights", "Lunch", "Personal shopping"],
    payment_modes: ["UPI", "Card", "Cash"],
    experiences: ["Beach hop", "Sunset cruise", "Nightlife tour"],
  },
  {
    _id: "pkg-manali",
    title: "Manali Adventure Tour",
    description: "Snowy views, adventure sports, and stunning mountain scenery await.",
    destination: "Manali",
    price: 14999,
    duration: "6 Days / 5 Nights",
    image: "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=900&q=80"
    ],
    inclusions: ["Adventure activities", "Hotel stay", "Meals", "Guide"],
    exclusions: ["Flights", "Personal expenses", "Premium gear"],
    payment_modes: ["UPI", "Card"],
    experiences: ["Snow adventure", "River rafting", "Mountain viewpoints"],
  },
  {
    _id: "pkg-darjeeling",
    title: "Darjeeling Tea Escape",
    description: "Discover charming railway routes, valley views, and heritage stays.",
    destination: "Darjeeling",
    price: 11999,
    duration: "4 Days / 3 Nights",
    image: "https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80"
    ],
    inclusions: ["Heritage stay", "Local sightseeing", "Meals", "Toy train ride"],
    exclusions: ["Flights", "Dinner", "Shopping"],
    payment_modes: ["UPI", "Card", "Cash"],
    experiences: ["Toy train ride", "Tea garden visit", "Sunrise point"],
  },
  {
    _id: "pkg-coorg",
    title: "Coorg Misty Getaway",
    description: "A peaceful holiday filled with coffee estates, rainforests, and waterfalls.",
    destination: "Coorg",
    price: 9999,
    duration: "3 Days / 2 Nights",
    image: "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1493558103817-58b2924bce98?auto=format&fit=crop&w=900&q=80"
    ],
    inclusions: ["Resort stay", "Breakfast", "Cab transfer", "Local guide"],
    exclusions: ["Flights", "Lunch", "Personal expenses"],
    payment_modes: ["UPI", "Card"],
    experiences: ["Coffee estate visit", "Waterfall trek", "Riverside stay"],
  },
];

export function getFallbackPackageById(id) {
  const normalizedId = String(id ?? "").trim().toLowerCase();

  return fallbackPackages.find((pkg) => {
    const candidateIds = [pkg._id, pkg.id].filter(Boolean).map((value) => String(value).trim().toLowerCase());
    return candidateIds.includes(normalizedId);
  });
}

export default fallbackPackages;
